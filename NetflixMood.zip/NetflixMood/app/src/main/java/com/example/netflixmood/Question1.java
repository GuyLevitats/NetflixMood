package com.example.netflixmood;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Question1 extends AppCompatActivity {

    private Button mButton, btNext;
    private TextView mTextView;
    private String typeMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        initUI();
        btnClicks();
    }

    private void initUI() {
        mButton = findViewById(R.id.alert2Btn);
        btNext = findViewById(R.id.btNext);
        mTextView = findViewById(R.id.aText);
    }

    private void btnClicks() {
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (typeMovie != null) {
                    Intent resultsIn = new Intent(getApplicationContext(), Question2.class);
                    resultsIn.putExtra("typeMovie", typeMovie);
                    startActivity(resultsIn);
                }
            }
        });

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Question1.this, R.style.AlertDialogThese);
                builder.setTitle("What type of movie/serie you want to watch?");
                builder.setIcon(R.drawable.ic_action_list);
                builder.setCancelable(false);

                final String[] listItems = new String[]{
                        "Comedy",
                        "Action",
                        "Drama"
                };

                builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mTextView.setText(listItems[which]);
                        typeMovie = listItems[which];
                        Toast.makeText(Question1.this, "your choice is-" + listItems[which], Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }

}
