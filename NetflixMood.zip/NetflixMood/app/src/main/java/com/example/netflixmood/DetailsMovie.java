package com.example.netflixmood;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Objects;

public class DetailsMovie extends AppCompatActivity {

    private TextView tvDetails;
    private FirebaseFirestore fireStoreDB;
    private String type, language, who, typeMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_movie);

        initUI();
        readFireStore();
    }

    private void initUI() {
        tvDetails = findViewById(R.id.tvDetails);

        type = getIntent().getStringExtra("type");
        language = getIntent().getStringExtra("language");
        who = getIntent().getStringExtra("who");
        typeMovie = getIntent().getStringExtra("typeMovie");

        fireStoreDB = FirebaseFirestore.getInstance();
    }

    private void readFireStore() {
        fireStoreDB.collection("movie")
                .whereEqualTo("type", type)
                .whereEqualTo("language", language)
                .whereEqualTo("who", who)
                .whereEqualTo("typeMovie", typeMovie)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : Objects.requireNonNull(task.getResult())) {
                                tvDetails.setText(document.getId());
                            }
                        } else {
                            Log.i("check1", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }

}
