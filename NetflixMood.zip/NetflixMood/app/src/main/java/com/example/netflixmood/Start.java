package com.example.netflixmood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class Start extends AppCompatActivity {

    private Button btMy;
    private Button btAll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        initUI();
        btnClicks();
    }

    private void initUI() {
        btMy = findViewById(R.id.btMy);
        btAll = findViewById(R.id.btAll);
    }

    private void btnClicks() {
        btMy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultsIn = new Intent(getApplicationContext(), Question1.class);
                startActivity(resultsIn);
            }
        });
        btAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultsIn = new Intent(getApplicationContext(), AllMovies.class);
                startActivity(resultsIn);
            }
        });
    }
}